CREATE DATABASE IF NOT EXISTS `sanpedro`;

USE `sanpedro`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `sp_acciones_decesivas`;

CREATE TABLE `sp_acciones_decesivas` (
  `id_acciones_decesivas` int(11) NOT NULL AUTO_INCREMENT,
  `subjetivo` varchar(250) DEFAULT NULL,
  `objetivo` varchar(250) DEFAULT NULL,
  `analisis` varchar(250) DEFAULT NULL,
  `plan_accion` varchar(250) DEFAULT NULL,
  `id_paciente` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_acciones_decesivas`),
  KEY `fk_acciones_decesivas_paciente` (`id_paciente`),
  CONSTRAINT `fk_acciones_decesivas_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `sp_paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `sp_acciones_decesivas` VALUES (1,"el paciente esta muy dolorido en la pieza dental ","hacer una extraccion de la pieza dental","se verifico que puede haber mas de una cita","paciente en estado conveniente para mantener sana su diente",1,"2021-06-21 10:04:01",NULL);


DROP TABLE IF EXISTS `sp_cita`;

CREATE TABLE `sp_cita` (
  `id_cita` int(11) NOT NULL AUTO_INCREMENT,
  `numero_cita` tinyint(4) DEFAULT NULL,
  `tipo_tratamiento` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `observacion` varchar(200) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha` date NOT NULL,
  `hora_inicio` time NOT NULL,
  `hora_final` time NOT NULL,
  `id_paciente` int(11) NOT NULL,
  `id_odontologo` int(11) NOT NULL,
  `costo` varchar(10) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estatus` enum('PENDIENTE','CANCELADA','ATENDIDA') COLLATE utf8_spanish_ci NOT NULL,
  `estado` tinyint(4) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_cita`),
  KEY `fk_cita_paciente` (`id_paciente`),
  KEY `fk_cita_odontologo` (`id_odontologo`),
  CONSTRAINT `fk_cita_odontologo` FOREIGN KEY (`id_odontologo`) REFERENCES `sp_odontologo` (`id_odontologo`),
  CONSTRAINT `fk_cita_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `sp_paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_cita` VALUES (1,2,"Restauracion","El paciente tiene una caries y debe ser restaurado","2021-06-09","14:30:00","15:00:00",3,2,"Gratuito","ATENDIDA",1,"2021-06-22 19:41:13","2021-06-22 19:41:29"),
(2,1,"Prevencion","El paciente tiene caries y debe hacer una prevecion","2021-06-22","16:00:00","16:29:00",4,5,"Gratuito","PENDIENTE",1,"2021-06-22 19:46:09",NULL),
(3,1,"Periodoncia","Paciente debe hacer un tratamiento de periodoncia","2021-06-24","14:00:00","14:30:00",6,2,"Gratuito","PENDIENTE",1,"2021-06-22 19:47:23",NULL),
(4,2,"Cirujia Bucal","El paciente debe hacerse una cirugia dental","2021-06-01","10:00:00","10:30:00",1,5,"Gratuito","CANCELADA",1,"2021-06-22 19:49:49","2021-06-22 19:50:03"),
(5,4,"Prevencion","El paciente necesita ser restaurado su diente molar derecho","2021-06-23","16:00:00","16:29:00",4,2,"Gratuito","ATENDIDA",1,"2021-06-22 22:04:03","2021-06-22 22:04:57");


DROP TABLE IF EXISTS `sp_diagnostico`;

CREATE TABLE `sp_diagnostico` (
  `id_diagnostico` int(11) NOT NULL AUTO_INCREMENT,
  `tipo_diagnostico` varchar(100) DEFAULT NULL,
  `pieza_dentaria` varchar(100) DEFAULT NULL,
  `medida_preventiva` varchar(150) DEFAULT NULL,
  `acciones_curativas` varchar(250) DEFAULT NULL,
  `id_paciente` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_diagnostico`),
  KEY `fk_diagnostico_paciente` (`id_paciente`),
  CONSTRAINT `fk_diagnostico_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `sp_paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `sp_diagnostico` VALUES (1,"Absceso Periapical Sin Fistula","diente numero 1 molar derecho","ninguno","Extracion",1,"2021-06-21 05:46:32",NULL);


DROP TABLE IF EXISTS `sp_grupo`;

CREATE TABLE `sp_grupo` (
  `id_grupo` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_grupo` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `estado_grupo` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_grupo`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_grupo` VALUES (1,"ADMINISTRADOR",1,"2021-02-15 11:55:05",NULL),
(2,"ODONTOLOGO",1,"2021-02-15 11:55:05",NULL),
(3,"PACIENTE",1,"2021-02-15 11:55:06",NULL);


DROP TABLE IF EXISTS `sp_grupo_usuario`;

CREATE TABLE `sp_grupo_usuario` (
  `id_grupo_usuario` int(11) NOT NULL AUTO_INCREMENT,
  `id_grupo` int(11) NOT NULL,
  `id_usuario` int(11) NOT NULL,
  `ip_usuario` varchar(30) COLLATE utf8_spanish_ci DEFAULT NULL,
  `navegador` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_grupo_usuario`),
  KEY `fk_grupousuario_grupo` (`id_grupo`),
  KEY `fk_grupousuario_usuario` (`id_usuario`),
  CONSTRAINT `fk_grupousuario_grupo` FOREIGN KEY (`id_grupo`) REFERENCES `sp_grupo` (`id_grupo`),
  CONSTRAINT `fk_grupousuario_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `sp_usuario` (`id_usuario`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_grupo_usuario` VALUES (1,1,1,"127.0.0.1","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0","2021-02-15 12:04:34","2021-06-04 09:15:16"),
(2,2,2,"127.0.0.1","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:89.0) Gecko/20100101 Firefox/89.0","2021-02-15 17:47:00","2021-05-25 21:07:52"),
(3,3,3,"127.0.0.1","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0","2021-02-19 18:01:47","2021-06-22 21:55:36"),
(4,3,4,"127.0.0.1","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0","2021-02-19 18:03:22","2021-06-22 19:38:19"),
(5,2,5,"127.0.0.1","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:87.0) Gecko/20100101 Firefox/87.0","2021-02-19 18:07:43","2021-03-17 23:01:27"),
(6,3,6,"127.0.0.1","Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:90.0) Gecko/20100101 Firefox/90.0","2021-03-12 19:41:06","2021-06-09 00:52:52");


DROP TABLE IF EXISTS `sp_lesiones_cariosas`;

CREATE TABLE `sp_lesiones_cariosas` (
  `id_lesiones_cariosas` int(11) NOT NULL AUTO_INCREMENT,
  `id_odontograma` int(11) DEFAULT NULL,
  `id_tratamiento_diagnostico` int(11) DEFAULT NULL,
  `posicion` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_lesiones_cariosas`),
  KEY `sp_lesiones_cariosas_fk` (`id_odontograma`),
  KEY `sp_lesiones_cariosas_fk1` (`id_tratamiento_diagnostico`),
  CONSTRAINT `sp_lesiones_cariosas_fk` FOREIGN KEY (`id_odontograma`) REFERENCES `sp_odontograma` (`id_odontograma`),
  CONSTRAINT `sp_lesiones_cariosas_fk1` FOREIGN KEY (`id_tratamiento_diagnostico`) REFERENCES `sp_tratamiento_diagnostico` (`id_tratamiento_diagnostico`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_lesiones_cariosas` VALUES (11,11,2,5,"2021-05-26 19:29:07",NULL),
(12,12,1,5,"2021-05-26 19:29:07",NULL),
(13,13,4,5,"2021-05-26 19:29:07",NULL),
(39,49,3,5,"2021-06-22 22:13:47",NULL),
(40,50,4,5,"2021-06-22 22:13:48",NULL),
(41,53,3,5,"2021-06-22 22:13:48",NULL),
(42,54,3,5,"2021-06-22 22:13:48",NULL);


DROP TABLE IF EXISTS `sp_medicacion`;

CREATE TABLE `sp_medicacion` (
  `id_medicacion` int(11) NOT NULL AUTO_INCREMENT,
  `entrega_medicamento` varchar(250) DEFAULT NULL,
  `receta_medica` varchar(250) DEFAULT NULL,
  `recomendaciones` varchar(250) DEFAULT NULL,
  `id_paciente` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_medicacion`),
  KEY `fk_medicacion_paciente` (`id_paciente`),
  CONSTRAINT `fk_medicacion_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `sp_paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

INSERT INTO `sp_medicacion` VALUES (1,"se entrega 5 unidades de paracetamol","tomar cada 5  horas","debe tomar los medicamentos con agua y 3 vces al dia",1,"2021-06-21 05:48:21",NULL);


DROP TABLE IF EXISTS `sp_ocupacion`;

CREATE TABLE `sp_ocupacion` (
  `id_ocupacion` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_ocupacion`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_ocupacion` VALUES (1,"albañil","2021-02-15 11:55:26",NULL),
(2,"Abogado","2021-02-15 11:55:26",NULL),
(3,"Administrador de fincas","2021-02-15 11:55:26",NULL),
(4,"Adornista","2021-02-15 11:55:26",NULL),
(5,"Afiliado","2021-02-15 11:55:26",NULL),
(6,"Agricultor","2021-02-15 11:55:26",NULL),
(7,"Agente de desarrollo local","2021-02-15 11:55:26",NULL),
(8,"Agente de viajes","2021-02-15 11:55:26",NULL),
(9,"Agente doble","2021-02-15 11:55:26",NULL),
(10,"Agente encubierto","2021-02-15 11:55:26",NULL),
(12,"Alguacil","2021-02-15 11:55:27",NULL),
(13,"Algueros","2021-02-15 11:55:27",NULL),
(14,"Ama de casa","2021-02-15 11:55:27",NULL),
(15,"Ama de crianza","2021-02-15 11:55:27",NULL),
(16,"Aprendiz","2021-02-15 11:55:27",NULL),
(17,"Archivero","2021-02-15 11:55:27",NULL),
(18,"Armero (profesi?n)","2021-02-15 11:55:27",NULL),
(19,"Arquitecto del paisaje","2021-02-15 11:55:27",NULL),
(20,"Ascensorista","2021-02-15 11:55:27",NULL),
(21,"Asesor (oficio)","2021-02-15 11:55:27",NULL),
(22,"Asesor financiero","2021-02-15 11:55:28",NULL),
(23,"Asesor fiscal","2021-02-15 11:55:28",NULL),
(24,"Asesor mercantil","2021-02-15 11:55:28",NULL),
(25,"Auditor","2021-02-15 11:55:28",NULL),
(26,"Barrendero","2021-02-15 11:55:28",NULL),
(27,"Basurero","2021-02-15 11:55:28",NULL),
(28,"Bedel","2021-02-15 11:55:28",NULL),
(29,"Bibliotecario","2021-02-15 11:55:28",NULL),
(30,"Br?ker","2021-02-15 11:55:28",NULL),
(31,"B?squeda de empleo","2021-02-15 11:55:28",NULL),
(32,"Calderero","2021-02-15 11:55:28",NULL),
(33,"Cambista","2021-02-15 11:55:28",NULL),
(34,"Cantante","2021-02-15 11:55:29",NULL),
(35,"Carretillero","2021-02-15 11:55:29",NULL),
(36,"Cartero","2021-02-15 11:55:29",NULL),
(37,"Cartoneo","2021-02-15 11:55:29",NULL),
(38,"Catador de alimentos","2021-02-15 11:55:29",NULL),
(39,"Cazador de sanguijuelas","2021-02-15 11:55:29",NULL),
(40,"Cazafantasmas (parapsicolog?a)","2021-02-15 11:55:29",NULL),
(41,"Cazatalentos","2021-02-15 11:55:29",NULL),
(42,"Chaman","2021-02-15 11:55:29",NULL),
(43,"Chofer","2021-02-15 11:55:29",NULL),
(44,"Comerciante","2021-02-15 11:55:29",NULL),
(45,"Cocinera","2021-02-15 11:55:29",NULL),
(46,"Condestable","2021-02-15 11:55:30",NULL),
(47,"Conserje","2021-02-15 11:55:30",NULL),
(48,"Consultor","2021-02-15 11:55:30",NULL),
(49,"Contador p?blico","2021-02-15 11:55:30",NULL),
(50,"Contenidista","2021-02-15 11:55:30",NULL),
(51,"Coolhunting","2021-02-15 11:55:30",NULL),
(52,"Corrector de textos","2021-02-15 11:55:30",NULL),
(53,"Corredor de apuestas","2021-02-15 11:55:30",NULL),
(54,"Corredor de seguros","2021-02-15 11:55:30",NULL),
(55,"Counseling","2021-02-15 11:55:30",NULL),
(56,"Crimin?logo","2021-02-15 11:55:30",NULL),
(57,"Crupier","2021-02-15 11:55:31",NULL),
(58,"Cuerpo de Registradores de la iedad, Mercantiles y de Bienes Muebles","2021-02-15 11:55:31",NULL),
(59,"Curandero","2021-02-15 11:55:31",NULL),
(60,"Decorador","2021-02-15 11:55:31",NULL),
(61,"Delineante","2021-02-15 11:55:31",NULL),
(62,"Diplom?tico","2021-02-15 11:55:31",NULL),
(63,"Director de colecci?n","2021-02-15 11:55:31",NULL),
(64,"Director de comunicaci?n","2021-02-15 11:55:31",NULL),
(65,"Diseñador","2021-02-15 11:55:31",NULL),
(66,"Estudiante","2021-02-15 11:55:31",NULL),
(67,"Economista","2021-02-15 11:55:31",NULL),
(68,"Editor de sonido","2021-02-15 11:55:32",NULL),
(69,"Facilitador","2021-02-15 11:55:32",NULL),
(70,"Fisioterapeuta","2021-02-15 11:55:32",NULL),
(71,"Estudiante univeritario","2021-02-15 11:55:32",NULL),
(72,"Gaberlunzie","2021-02-15 11:55:32",NULL),
(73,"Garimpeiro","2021-02-15 11:55:32",NULL),
(74,"Geisha","2021-02-15 11:55:32",NULL),
(75,"Ganadero","2021-02-15 11:55:32",NULL),
(76,"Gu?a acompa?ante","2021-02-15 11:55:32",NULL),
(77,"Gu?a de turismo","2021-02-15 11:55:32",NULL),
(78,"Gu?a de monta?a","2021-02-15 11:55:33",NULL),
(79,"Hechicero","2021-02-15 11:55:33",NULL),
(80,"Historietista","2021-02-15 11:55:33",NULL),
(81,"Hombre anuncio","2021-02-15 11:55:33",NULL),
(82,"Hospitalero","2021-02-15 11:55:33",NULL),
(83,"Inform?tico","2021-02-15 11:55:33",NULL),
(84,"Ingeniero(a) geol?gica","2021-02-15 11:55:33",NULL),
(85,"Ingeniero de software","2021-02-15 11:55:33",NULL),
(86,"Ingeniero mecanico","2021-02-15 11:55:33",NULL),
(87,"Ingeniero de Sistemas","2021-02-15 11:55:33",NULL),
(88,"Ingeniero de civil","2021-02-15 11:55:34",NULL),
(89,"Ingeniero de sonido","2021-02-15 11:55:34",NULL),
(90,"Ingeniero electr?nico","2021-02-15 11:55:34",NULL),
(91,"Integrador social","2021-02-15 11:55:34",NULL),
(92,"Int?rprete (profesi?n)","2021-02-15 11:55:34",NULL),
(93,"Investigador","2021-02-15 11:55:34",NULL),
(94,"Jardinero","2021-02-15 11:55:34",NULL),
(95,"Jugador de videojuegos","2021-02-15 11:55:34",NULL),
(96,"Lapidario (profesi?n)","2021-02-15 11:55:34",NULL),
(97,"Leñador","2021-02-15 11:55:35",NULL),
(98,"Limpiabotas","2021-02-15 11:55:35",NULL),
(99,"Lord gran chambel?n","2021-02-15 11:55:35",NULL),
(100,"Maestro de esp?as","2021-02-15 11:55:35",NULL),
(101,"Mandatario Registral de Automotores","2021-02-15 11:55:35",NULL),
(102,"Manicura (ocupaci?n)","2021-02-15 11:55:35",NULL),
(103,"Martillero p?blico","2021-02-15 11:55:35",NULL),
(104,"Masajista","2021-02-15 11:55:35",NULL),
(105,"Mecanico","2021-02-15 11:55:35",NULL),
(107,"Mensajero","2021-02-15 11:55:35",NULL),
(108,"Minero","2021-02-15 11:55:36",NULL),
(109,"Oficio (profesi?n)","2021-02-15 11:55:36",NULL),
(110,"Oiran","2021-02-15 11:55:36",NULL),
(111,"Ojeador","2021-02-15 11:55:36",NULL),
(112,"Nai Palm","2021-02-15 11:55:36",NULL),
(113,"Peluquero","2021-02-15 11:55:36",NULL),
(114,"Peluquero canino","2021-02-15 11:55:36",NULL),
(115,"Profesor","2021-02-15 11:55:36",NULL),
(116,"Planificador financiero","2021-02-15 11:55:37",NULL),
(117,"Policia","2021-02-15 11:55:37",NULL),
(118,"Portero de edificio","2021-02-15 11:55:37",NULL),
(119,"Profesional","2021-02-15 11:55:37",NULL),
(120,"Otro","2021-02-15 11:55:38",NULL),
(121,"Recaudador de impuestos","2021-02-15 11:55:38",NULL),
(122,"Reciclador de base","2021-02-15 11:55:38",NULL),
(123,"Reservista","2021-02-15 11:55:38",NULL),
(124,"Riacheros","2021-02-15 11:55:38",NULL),
(125,"Socialite","2021-02-15 11:55:38",NULL),
(126,"Socorrista acu?tico","2021-02-15 11:55:38",NULL),
(127,"Taquillero","2021-02-15 11:55:38",NULL),
(128,"T?cnico de Laboratorio de Universidad","2021-02-15 11:55:38",NULL),
(129,"T?cnico de sistemas","2021-02-15 11:55:38",NULL),
(130,"Telefonista","2021-02-15 11:55:39",NULL),
(131,"Tesorero","2021-02-15 11:55:39",NULL),
(132,"Trabajador aut?nomo","2021-02-15 11:55:39",NULL),
(133,"Valet parking","2021-02-15 11:55:39",NULL),
(134,"Veedor (viticultura)","2021-02-15 11:55:39",NULL),
(135,"Verdugo","2021-02-15 11:55:41",NULL);


DROP TABLE IF EXISTS `sp_odontograma`;

CREATE TABLE `sp_odontograma` (
  `id_odontograma` int(11) NOT NULL AUTO_INCREMENT,
  `id_paciente` int(11) DEFAULT NULL,
  `id_pieza_dental` int(11) DEFAULT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_odontograma`),
  KEY `sp_odontograma_fk` (`id_paciente`),
  KEY `sp_odontograma_fk1` (`id_pieza_dental`),
  CONSTRAINT `sp_odontograma_fk` FOREIGN KEY (`id_paciente`) REFERENCES `sp_paciente` (`id_paciente`),
  CONSTRAINT `sp_odontograma_fk1` FOREIGN KEY (`id_pieza_dental`) REFERENCES `sp_pieza_dental` (`id_pieza_dental`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_odontograma` VALUES (11,3,23,"2021-05-26 19:29:07",NULL),
(12,3,7,"2021-05-26 19:29:07",NULL),
(13,3,25,"2021-05-26 19:29:07",NULL),
(46,1,24,"2021-06-22 22:13:47",NULL),
(47,1,7,"2021-06-22 22:13:47",NULL),
(48,1,25,"2021-06-22 22:13:47",NULL),
(49,1,9,"2021-06-22 22:13:47",NULL),
(50,1,27,"2021-06-22 22:13:48",NULL),
(51,1,2,"2021-06-22 22:13:48",NULL),
(52,1,21,"2021-06-22 22:13:48",NULL),
(53,1,3,"2021-06-22 22:13:48",NULL),
(54,1,23,"2021-06-22 22:13:48",NULL),
(55,1,28,"2021-06-22 22:13:48",NULL);


DROP TABLE IF EXISTS `sp_odontologo`;

CREATE TABLE `sp_odontologo` (
  `id_odontologo` int(11) NOT NULL,
  `turno` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `gestion_ingreso` year(4) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_odontologo`),
  CONSTRAINT `fk_persona_odontologo` FOREIGN KEY (`id_odontologo`) REFERENCES `sp_persona` (`id_persona`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_odontologo` VALUES (2,"MAÑANA-TARDE",2020,"2021-02-15 17:47:00","2021-05-25 21:07:52"),
(5,"MAÑANA",2019,"2021-02-19 18:07:43","2021-03-17 23:01:27");


DROP TABLE IF EXISTS `sp_paciente`;

CREATE TABLE `sp_paciente` (
  `id_paciente` int(11) NOT NULL,
  `id_ocupacion` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_paciente`),
  KEY `fk_paciente_ocupacion` (`id_ocupacion`),
  CONSTRAINT `fk_paciente_ocupacion` FOREIGN KEY (`id_ocupacion`) REFERENCES `sp_ocupacion` (`id_ocupacion`),
  CONSTRAINT `fk_persona_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `sp_persona` (`id_persona`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_paciente` VALUES (1,5,"2021-02-15 12:04:34","2021-06-04 09:15:16"),
(3,25,"2021-02-19 18:01:47","2021-06-22 21:55:36"),
(4,1,"2021-02-19 18:03:22","2021-06-22 19:38:19"),
(6,2,"2021-03-12 19:41:06","2021-06-09 00:52:52");


DROP TABLE IF EXISTS `sp_persona`;

CREATE TABLE `sp_persona` (
  `id_persona` int(11) NOT NULL AUTO_INCREMENT,
  `ci` int(11) NOT NULL,
  `expedido` varchar(4) COLLATE utf8_spanish_ci NOT NULL,
  `nombres` varchar(50) COLLATE utf8_spanish_ci NOT NULL,
  `paterno` varchar(25) COLLATE utf8_spanish_ci NOT NULL,
  `materno` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `sexo` varchar(20) COLLATE utf8_spanish_ci NOT NULL,
  `lugar_nacimiento` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `telefono_celular` varchar(20) COLLATE utf8_spanish_ci DEFAULT NULL,
  `fecha_nacimiento` date DEFAULT NULL,
  `domicilio` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estatus` enum('ACTIVO','INACTIVO') COLLATE utf8_spanish_ci NOT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_persona`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_persona` VALUES (1,12345678,"LP","Fernando","Chambi","Bautista","masculino","Coroico",67333533,"2021-03-22","pinos el alto","ACTIVO",1,"2021-02-15 12:04:34","2021-06-04 09:15:16"),
(2,10907085,"LP","Luis","Chambi","Bautista","","",67333533,"1995-03-22","San Felipe","ACTIVO",1,"2021-02-15 17:47:00","2021-05-25 21:07:52"),
(3,10907080,"LP","Jorge Luis","Flores","Campos","masculino","kiswaras Zona norte",7658956,"1999-02-16","kiswaras","ACTIVO",1,"2021-02-19 18:01:47","2021-06-22 21:55:36"),
(4,25896312,"CH","Hernan","Cortez","Charca","masculino","Vilacota",25896321,"1995-03-22","Pinos ","ACTIVO",1,"2021-02-19 18:03:22","2021-06-22 19:38:19"),
(5,14785896,"LP","Pablo","Montes","Carbajal","","",78596321,"1708-02-15","Senkata","INACTIVO",1,"2021-02-19 18:07:43","2021-03-17 23:01:27"),
(6,20252365,"CH","Franklim","Terrazas","Curvo","masculino","su zona",75896325,"2021-03-01","palos blancos","INACTIVO",1,"2021-03-12 19:41:06","2021-06-09 00:52:52"),
(7,45896,"LP","Rodolfo","Quispe","Quispe","","",54869562,"2021-05-18","nknjkkk ","ACTIVO",0,"2021-05-09 00:19:25","2021-05-09 22:08:11"),
(8,15856985,"CH","Elias","Apaza","Ajno","masculino","san pedro de curahuara",45653334,"2021-05-01","san pedro","ACTIVO",1,"2021-05-16 17:44:15","2021-06-18 14:10:15"),
(9,102589,"LP","Nombre","Choque","Materno","masculino","lugar",4587865,"2021-05-13","domi","ACTIVO",0,"2021-05-25 22:50:19",NULL),
(10,412569863,"LP","Quispe","Quispe","Quispe","masculino","quispe",458962,"2021-05-13","quispe","ACTIVO",1,"2021-05-25 22:57:52",NULL),
(11,14589,"CH","Hola","Hola","Hola","femenino","hola",145896,"2021-05-13","domis","ACTIVO",1,"2021-05-25 23:17:52",NULL),
(12,1099887,"CH","Joj","Jo","Jo","femenino","jo",1545895,"2021-05-26","jo","ACTIVO",1,"2021-05-25 23:23:11","2021-06-04 10:35:12"),
(13,10258963,"CH","Nn","Nn","Nn","masculino","nn",7458962,"2021-05-18","nn","INACTIVO",1,"2021-05-26 00:05:43",NULL);


DROP TABLE IF EXISTS `sp_pieza_dental`;

CREATE TABLE `sp_pieza_dental` (
  `id_pieza_dental` int(11) NOT NULL AUTO_INCREMENT,
  `numero_pieza_dental` int(11) DEFAULT NULL,
  PRIMARY KEY (`id_pieza_dental`)
) ENGINE=InnoDB AUTO_INCREMENT=53 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_pieza_dental` VALUES (1,1),
(2,2),
(3,3),
(4,4),
(5,5),
(6,6),
(7,7),
(8,8),
(9,9),
(10,10),
(11,11),
(12,12),
(13,13),
(14,14),
(15,15),
(16,16),
(17,17),
(18,18),
(19,19),
(20,20),
(21,21),
(22,22),
(23,23),
(24,24),
(25,25),
(26,26),
(27,27),
(28,28),
(29,29),
(30,30),
(31,31),
(32,32),
(33,33),
(34,34),
(35,35),
(36,36),
(37,37),
(38,38),
(39,39),
(40,40),
(41,41),
(42,42),
(43,43),
(44,44),
(45,45),
(46,46),
(47,47),
(48,48),
(49,49),
(50,50),
(51,51),
(52,52);


DROP TABLE IF EXISTS `sp_tratamiento_alergias`;

CREATE TABLE `sp_tratamiento_alergias` (
  `id_alergia` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_alergia` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `detalle` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_paciente` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_alergia`),
  KEY `fk_tratamiento_alergias_paciente` (`id_paciente`),
  CONSTRAINT `fk_tratamiento_alergias_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `sp_paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_tratamiento_alergias` VALUES (3,"pastillas","es alergico a las pastillas grandes",1,"2021-06-06 08:29:03","2021-06-26 19:26:12");


DROP TABLE IF EXISTS `sp_tratamiento_consulta`;

CREATE TABLE `sp_tratamiento_consulta` (
  `id_consulta` int(11) NOT NULL AUTO_INCREMENT,
  `tratamiento` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `motivo_tratamiento` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `alergico_medicamento` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cual_medicamento` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `alguna_cirugia` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `porque` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `alguna_enfermedad` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cepilla_diente` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `cuanto_dia` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_paciente` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_consulta`),
  KEY `fk_tratamiento_consulta_paciente` (`id_paciente`),
  CONSTRAINT `fk_tratamiento_consulta_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `sp_paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_tratamiento_consulta` VALUES (1,"no",NULL,"si","refrianex","si","por motivo de extraccion de diente","epatitis","no"," ",1,"2021-05-29 12:44:24","2021-06-30 21:37:58"),
(2,"si","dolor de mis dientes","si ","pastillas","si","por extraccion","asma","si","una vez a la semana",4,"2021-05-31 19:38:24",NULL);


DROP TABLE IF EXISTS `sp_tratamiento_diagnostico`;

CREATE TABLE `sp_tratamiento_diagnostico` (
  `id_tratamiento_diagnostico` int(11) NOT NULL AUTO_INCREMENT,
  `nombre_tratamiento_diagnostico` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `estado` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id_tratamiento_diagnostico`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_tratamiento_diagnostico` VALUES (1,"Amalgama",1),
(2,"Caries",1),
(3,"Endodoncia",1),
(4,"Ausente",1),
(5,"Resina",1);


DROP TABLE IF EXISTS `sp_tratamiento_enfermedad`;

CREATE TABLE `sp_tratamiento_enfermedad` (
  `id_enfermedad` int(11) NOT NULL AUTO_INCREMENT,
  `tiempo_consulta` varchar(50) COLLATE utf8_spanish_ci DEFAULT NULL,
  `motivo_consulta` varchar(100) COLLATE utf8_spanish_ci DEFAULT NULL,
  `sintomas_principales` varchar(150) COLLATE utf8_spanish_ci DEFAULT NULL,
  `tomando_medicamentos` varchar(25) COLLATE utf8_spanish_ci DEFAULT NULL,
  `nombre_medicamento` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `motivo_medicamento` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `dosis_medicamento` varchar(250) COLLATE utf8_spanish_ci DEFAULT NULL,
  `id_paciente` int(11) NOT NULL,
  PRIMARY KEY (`id_enfermedad`),
  KEY `fk_tratamiento_enfermedad_paciente` (`id_paciente`),
  CONSTRAINT `fk_tratamiento_enfermedad_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `sp_paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_tratamiento_enfermedad` VALUES (2,"2 semana","restauracion de diente","fiebre y dolor bucal","no",NULL,NULL,NULL,1);


DROP TABLE IF EXISTS `sp_tratamiento_fisico`;

CREATE TABLE `sp_tratamiento_fisico` (
  `id_fisico` int(11) NOT NULL AUTO_INCREMENT,
  `presion_arterial` decimal(5,2) DEFAULT NULL,
  `pulso` decimal(5,2) DEFAULT NULL,
  `temperatura` decimal(5,2) DEFAULT NULL,
  `frecuencia_cardiaca` decimal(5,2) DEFAULT NULL,
  `frecuencia_respiratoria` decimal(5,2) DEFAULT NULL,
  `peso` decimal(5,2) DEFAULT NULL,
  `talla` decimal(5,2) DEFAULT NULL,
  `masa_corporal` decimal(5,2) DEFAULT NULL,
  `id_paciente` int(11) NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_fisico`),
  KEY `fk_tratamiento_fisico_paciente` (`id_paciente`),
  CONSTRAINT `fk_tratamiento_fisico_paciente` FOREIGN KEY (`id_paciente`) REFERENCES `sp_paciente` (`id_paciente`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_tratamiento_fisico` VALUES (1,"20.30","44.00","21.00","4.00","3.00","50.00","1.67","50.00",1,"2021-05-29 12:48:32","2021-06-05 23:50:23"),
(2,"0.99","23.00","20.00","3.00","2.00","2.00","69.00","50.00",4,"2021-05-31 19:49:44",NULL);


DROP TABLE IF EXISTS `sp_usuario`;

CREATE TABLE `sp_usuario` (
  `id_usuario` int(11) NOT NULL,
  `usuario` varchar(30) COLLATE utf8_spanish_ci NOT NULL,
  `clave` varchar(256) COLLATE utf8_spanish_ci NOT NULL,
  `foto` varchar(100) COLLATE utf8_spanish_ci NOT NULL,
  `creado_en` timestamp NOT NULL DEFAULT current_timestamp(),
  `actualizado_en` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id_usuario`),
  CONSTRAINT `fk_persona_usuario` FOREIGN KEY (`id_usuario`) REFERENCES `sp_persona` (`id_persona`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci;

INSERT INTO `sp_usuario` VALUES (1,"FERNANDO_12345678","b035a3f36b4f8af7ed56bcdd1873d286f33465d261db02a3450f8a0c13bd7b54f8030115de64a1c9064d4915b1b9ba2e2eb39b943fa24da24abdf1ce29e556c3","img/users/1624764278_d44b9b2e03d4b5dd1216.png","2021-02-15 12:04:34","2021-06-04 09:15:16"),
(2,"LUIS_10907085","13b6f194fc15b72a711b7bcea693bf5a3433a94138412450dd8e54e1ca16d1c1a10bc80d8942690137024e651190d56abcd94c239cba4dd506b78d057c6bfbf4","","2021-02-15 17:47:00","2021-05-25 21:07:52"),
(3,"JORGE_10907080","6ee7c7c5db1e16ae05d0fa94a743f7a6a573dcbcd2d7d1c698bf891584c77030be3fd5e7fa1180ad80509e5291e9fd9bd3c370b93b2f54f82eed2c899e8c8cbe","img/users/1624415689_9a34ae7efe6d4b0ead1f.png","2021-02-19 18:01:47","2021-06-22 21:55:36"),
(4,"HERNAN_25896312","13b6f194fc15b72a711b7bcea693bf5a3433a94138412450dd8e54e1ca16d1c1a10bc80d8942690137024e651190d56abcd94c239cba4dd506b78d057c6bfbf4","","2021-02-19 18:03:22","2021-06-22 19:38:19"),
(5,"PABLO_14785896","e9c1f76bcf22743e80a20529a38f89bfedae0e9bb386f67205ee5f558a577626cf63dbbc9d68830dbaf4fcbd2e5c39c65b318026f778ebc3020430a3dd72fdd2","","2021-02-19 18:07:43","2021-03-17 23:01:27"),
(6,"FRANKLIM_20252365","3f3c994433fc03012a5c1d6b0e09dc1063c58d2aeb05e43fdfdaa0ae67c2d10367e342e337b77f8872805b1b2c333e23642fa7460852a6c4912619d9fe96c334","","2021-03-12 19:41:06","2021-06-09 00:52:52");


DROP TABLE IF EXISTS `sp_view_cita`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sp_view_cita` AS select `cita`.`id_cita` AS `id_cita`,`cita`.`numero_cita` AS `numero_cita`,`cita`.`tipo_tratamiento` AS `tipo_tratamiento`,`cita`.`observacion` AS `observacion`,`cita`.`fecha` AS `fecha`,`cita`.`hora_inicio` AS `hora_inicio`,`cita`.`hora_final` AS `hora_final`,`cita`.`costo` AS `costo`,`cita`.`estatus` AS `estatus`,`cita`.`estado` AS `estado`,`paciente`.`id_paciente` AS `id_paciente`,concat(`persona_paciente`.`nombres`,' ',`persona_paciente`.`paterno`,' ',`persona_paciente`.`materno`) AS `nombre_paciente`,concat(`persona_paciente`.`ci`,' ',`persona_paciente`.`expedido`) AS `ci_paciente`,`odontologo`.`id_odontologo` AS `id_odontologo`,concat(`persona_odontologo`.`nombres`,' ',`persona_odontologo`.`paterno`,' ',`persona_odontologo`.`materno`) AS `nombre_odontologo`,concat(`persona_odontologo`.`ci`,' ',`persona_odontologo`.`expedido`) AS `ci_odontologo`,`cita`.`creado_en` AS `creado_en` from ((((`sp_cita` `cita` join `sp_paciente` `paciente` on(`cita`.`id_paciente` = `paciente`.`id_paciente`)) join `sp_persona` `persona_paciente` on(`persona_paciente`.`id_persona` = `paciente`.`id_paciente`)) join `sp_odontologo` `odontologo` on(`cita`.`id_odontologo` = `odontologo`.`id_odontologo`)) join `sp_persona` `persona_odontologo` on(`odontologo`.`id_odontologo` = `persona_odontologo`.`id_persona`));

INSERT INTO `sp_view_cita` VALUES (1,2,"Restauracion","El paciente tiene una caries y debe ser restaurado","2021-06-09","14:30:00","15:00:00","Gratuito","ATENDIDA",1,3,"Jorge Luis Flores Campos","10907080 LP",2,"Luis Chambi Bautista","10907085 LP","2021-06-22 19:41:13"),
(2,1,"Prevencion","El paciente tiene caries y debe hacer una prevecion","2021-06-22","16:00:00","16:29:00","Gratuito","PENDIENTE",1,4,"Hernan Cortez Charca","25896312 CH",5,"Pablo Montes Carbajal","14785896 LP","2021-06-22 19:46:09"),
(3,1,"Periodoncia","Paciente debe hacer un tratamiento de periodoncia","2021-06-24","14:00:00","14:30:00","Gratuito","PENDIENTE",1,6,"Franklim Terrazas Curvo","20252365 CH",2,"Luis Chambi Bautista","10907085 LP","2021-06-22 19:47:23"),
(4,2,"Cirujia Bucal","El paciente debe hacerse una cirugia dental","2021-06-01","10:00:00","10:30:00","Gratuito","CANCELADA",1,1,"Fernando Chambi Bautista","12345678 LP",5,"Pablo Montes Carbajal","14785896 LP","2021-06-22 19:49:49"),
(5,4,"Prevencion","El paciente necesita ser restaurado su diente molar derecho","2021-06-23","16:00:00","16:29:00","Gratuito","ATENDIDA",1,4,"Hernan Cortez Charca","25896312 CH",2,"Luis Chambi Bautista","10907085 LP","2021-06-22 22:04:03");


DROP TABLE IF EXISTS `sp_view_odontologo`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sp_view_odontologo` AS select `p`.`id_persona` AS `id_persona`,concat(`p`.`ci`,' ',`p`.`expedido`) AS `ci_exp`,concat(`p`.`nombres`,' ',`p`.`paterno`,' ',`p`.`materno`) AS `nombre_completo`,`p`.`telefono_celular` AS `telefono_celular`,`p`.`fecha_nacimiento` AS `fecha_nacimiento`,`p`.`domicilio` AS `domicilio`,`o`.`turno` AS `turno`,`o`.`gestion_ingreso` AS `gestion_ingreso`,`p`.`estatus` AS `estatus`,`p`.`estado` AS `estado`,`p`.`creado_en` AS `creado_en` from (`sp_persona` `p` join `sp_odontologo` `o` on(`p`.`id_persona` = `o`.`id_odontologo`));

INSERT INTO `sp_view_odontologo` VALUES (2,"10907085 LP","Luis Chambi Bautista",67333533,"1995-03-22","San Felipe","MAÑANA-TARDE",2020,"ACTIVO",1,"2021-02-15 17:47:00"),
(5,"14785896 LP","Pablo Montes Carbajal",78596321,"1708-02-15","Senkata","MAÑANA",2019,"INACTIVO",1,"2021-02-19 18:07:43");


DROP TABLE IF EXISTS `sp_view_paciente`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sp_view_paciente` AS select `p`.`id_persona` AS `id_persona`,concat(`p`.`ci`,' ',`p`.`expedido`) AS `ci_exp`,concat(`p`.`nombres`,' ',`p`.`paterno`,' ',`p`.`materno`) AS `nombre_completo`,`p`.`sexo` AS `sexo`,`p`.`lugar_nacimiento` AS `lugar_nacimiento`,`p`.`telefono_celular` AS `telefono_celular`,`p`.`fecha_nacimiento` AS `fecha_nacimiento`,`p`.`domicilio` AS `domicilio`,`o`.`id_ocupacion` AS `id_ocupacion`,`o`.`nombre` AS `ocupacion`,`p`.`estatus` AS `estatus`,`p`.`estado` AS `estado`,`p`.`creado_en` AS `creado_en` from ((`sp_persona` `p` join `sp_paciente` `pa` on(`p`.`id_persona` = `pa`.`id_paciente`)) join `sp_ocupacion` `o` on(`pa`.`id_ocupacion` = `o`.`id_ocupacion`));

INSERT INTO `sp_view_paciente` VALUES (4,"25896312 CH","Hernan Cortez Charca","masculino","Vilacota",25896321,"1995-03-22","Pinos ",1,"albañil","ACTIVO",1,"2021-02-19 18:03:22"),
(6,"20252365 CH","Franklim Terrazas Curvo","masculino","su zona",75896325,"2021-03-01","palos blancos",2,"Abogado","INACTIVO",1,"2021-03-12 19:41:06"),
(1,"12345678 LP","Fernando Chambi Bautista","masculino","Coroico",67333533,"2021-03-22","pinos el alto",5,"Afiliado","ACTIVO",1,"2021-02-15 12:04:34"),
(3,"10907080 LP","Jorge Luis Flores Campos","masculino","kiswaras Zona norte",7658956,"1999-02-16","kiswaras",25,"Auditor","ACTIVO",1,"2021-02-19 18:01:47");


DROP TABLE IF EXISTS `sp_view_tratamiento_alergias`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sp_view_tratamiento_alergias` AS select `tratamiento_alergias`.`id_alergia` AS `id_alergia`,`tratamiento_alergias`.`nombre_alergia` AS `nombre_alergia`,`tratamiento_alergias`.`detalle` AS `detalle`,`paciente`.`id_paciente` AS `id_paciente`,concat(`persona_paciente`.`nombres`,' ',`persona_paciente`.`paterno`,' ',`persona_paciente`.`materno`) AS `nombre_paciente`,concat(`persona_paciente`.`ci`,' ',`persona_paciente`.`expedido`) AS `ci_paciente`,`tratamiento_alergias`.`creado_en` AS `creado_en` from ((`sp_tratamiento_alergias` `tratamiento_alergias` join `sp_paciente` `paciente` on(`tratamiento_alergias`.`id_paciente` = `paciente`.`id_paciente`)) join `sp_persona` `persona_paciente` on(`persona_paciente`.`id_persona` = `paciente`.`id_paciente`));

INSERT INTO `sp_view_tratamiento_alergias` VALUES (3,"pastillas","es alergico a las pastillas grandes",1,"Fernando Chambi Bautista","12345678 LP","2021-06-06 08:29:03");


DROP TABLE IF EXISTS `sp_view_tratamiento_consulta`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sp_view_tratamiento_consulta` AS select `tratamiento_consulta`.`id_consulta` AS `id_consulta`,`tratamiento_consulta`.`tratamiento` AS `tratamiento`,`tratamiento_consulta`.`motivo_tratamiento` AS `motivo_tratamiento`,`tratamiento_consulta`.`alergico_medicamento` AS `alergico_medicamento`,`tratamiento_consulta`.`cual_medicamento` AS `cual_medicamento`,`tratamiento_consulta`.`alguna_cirugia` AS `alguna_cirugia`,`tratamiento_consulta`.`porque` AS `porque`,`tratamiento_consulta`.`alguna_enfermedad` AS `alguna_enfermedad`,`tratamiento_consulta`.`cepilla_diente` AS `cepilla_diente`,`tratamiento_consulta`.`cuanto_dia` AS `cuanto_dia`,`paciente`.`id_paciente` AS `id_paciente`,concat(`persona_paciente`.`nombres`,' ',`persona_paciente`.`paterno`,' ',`persona_paciente`.`materno`) AS `nombre_paciente`,`tratamiento_consulta`.`creado_en` AS `creado_en` from ((`sp_tratamiento_consulta` `tratamiento_consulta` join `sp_paciente` `paciente` on(`tratamiento_consulta`.`id_paciente` = `paciente`.`id_paciente`)) join `sp_persona` `persona_paciente` on(`persona_paciente`.`id_persona` = `paciente`.`id_paciente`));

INSERT INTO `sp_view_tratamiento_consulta` VALUES (1,"no",NULL,"si","refrianex","si","por motivo de extraccion de diente","epatitis","no"," ",1,"Fernando Chambi Bautista","2021-05-29 12:44:24"),
(2,"si","dolor de mis dientes","si ","pastillas","si","por extraccion","asma","si","una vez a la semana",4,"Hernan Cortez Charca","2021-05-31 19:38:24");


DROP TABLE IF EXISTS `sp_view_tratamiento_enfermedad`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sp_view_tratamiento_enfermedad` AS select `tratamiento_enfermedad`.`id_enfermedad` AS `id_enfermedad`,`tratamiento_enfermedad`.`tiempo_consulta` AS `tiempo_consulta`,`tratamiento_enfermedad`.`motivo_consulta` AS `motivo_consulta`,`tratamiento_enfermedad`.`sintomas_principales` AS `sintomas_principales`,`tratamiento_enfermedad`.`tomando_medicamentos` AS `tomando_medicamento`,`tratamiento_enfermedad`.`nombre_medicamento` AS `nombre_medicamento`,`tratamiento_enfermedad`.`motivo_medicamento` AS `motivo_medicamento`,`tratamiento_enfermedad`.`dosis_medicamento` AS `dosis_medicamento`,`paciente`.`id_paciente` AS `id_paciente`,concat(`persona_paciente`.`nombres`,' ',`persona_paciente`.`paterno`,' ',`persona_paciente`.`materno`) AS `nombre_paciente` from ((`sp_tratamiento_enfermedad` `tratamiento_enfermedad` join `sp_paciente` `paciente` on(`tratamiento_enfermedad`.`id_paciente` = `paciente`.`id_paciente`)) join `sp_persona` `persona_paciente` on(`persona_paciente`.`id_persona` = `paciente`.`id_paciente`));

INSERT INTO `sp_view_tratamiento_enfermedad` VALUES (2,"2 semana","restauracion de diente","fiebre y dolor bucal","no",NULL,NULL,NULL,1,"Fernando Chambi Bautista");


DROP TABLE IF EXISTS `sp_view_tratamiento_fisico`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sp_view_tratamiento_fisico` AS select `tratamiento_fisico`.`id_fisico` AS `id_fisico`,`tratamiento_fisico`.`presion_arterial` AS `presion_alterial`,`tratamiento_fisico`.`pulso` AS `pulso`,`tratamiento_fisico`.`temperatura` AS `temperatura`,`tratamiento_fisico`.`frecuencia_cardiaca` AS `frecuencia_cardiaca`,`tratamiento_fisico`.`frecuencia_respiratoria` AS `frecuencia_respiratoria`,`tratamiento_fisico`.`peso` AS `peso`,`tratamiento_fisico`.`talla` AS `talla`,`tratamiento_fisico`.`masa_corporal` AS `masa_corporal`,`paciente`.`id_paciente` AS `id_paciente`,concat(`persona_paciente`.`nombres`,' ',`persona_paciente`.`paterno`,' ',`persona_paciente`.`materno`) AS `nombre_paciente`,`tratamiento_fisico`.`creado_en` AS `creado_en` from ((`sp_tratamiento_fisico` `tratamiento_fisico` join `sp_paciente` `paciente` on(`tratamiento_fisico`.`id_paciente` = `paciente`.`id_paciente`)) join `sp_persona` `persona_paciente` on(`persona_paciente`.`id_persona` = `paciente`.`id_paciente`));

INSERT INTO `sp_view_tratamiento_fisico` VALUES (1,"20.30","44.00","21.00","4.00","3.00","50.00","1.67","50.00",1,"Fernando Chambi Bautista","2021-05-29 12:48:32"),
(2,"0.99","23.00","20.00","3.00","2.00","2.00","69.00","50.00",4,"Hernan Cortez Charca","2021-05-31 19:49:44");


DROP TABLE IF EXISTS `sp_view_users`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY DEFINER VIEW `sp_view_users` AS select `p`.`id_persona` AS `id_persona`,`p`.`ci` AS `ci`,`p`.`expedido` AS `expedido`,`p`.`paterno` AS `paterno`,`p`.`materno` AS `materno`,`p`.`nombres` AS `nombres`,`p`.`fecha_nacimiento` AS `fecha_nacimiento`,`p`.`telefono_celular` AS `telefono_celular`,`p`.`domicilio` AS `domicilio`,`p`.`creado_en` AS `creado_en`,`p`.`actualizado_en` AS `actualizado_en`,`p`.`estado` AS `estado`,`u`.`usuario` AS `usuario`,`u`.`clave` AS `clave`,`u`.`foto` AS `foto`,`gu`.`id_grupo_usuario` AS `id_grupo_usuario`,`gu`.`id_grupo` AS `id_grupo`,`gu`.`id_usuario` AS `id_usuario`,`gu`.`ip_usuario` AS `ip_usuario`,`g`.`nombre_grupo` AS `nombre_grupo`,`g`.`estado_grupo` AS `estado_grupo` from (((`sp_usuario` `u` join `sp_persona` `p` on(`p`.`id_persona` = `u`.`id_usuario`)) left join `sp_grupo_usuario` `gu` on(`gu`.`id_usuario` = `u`.`id_usuario`)) left join `sp_grupo` `g` on(`g`.`id_grupo` = `gu`.`id_grupo`));

INSERT INTO `sp_view_users` VALUES (1,12345678,"LP","Chambi","Bautista","Fernando","2021-03-22",67333533,"pinos el alto","2021-02-15 12:04:34","2021-06-04 09:15:16",1,"FERNANDO_12345678","b035a3f36b4f8af7ed56bcdd1873d286f33465d261db02a3450f8a0c13bd7b54f8030115de64a1c9064d4915b1b9ba2e2eb39b943fa24da24abdf1ce29e556c3","img/users/1624764278_d44b9b2e03d4b5dd1216.png",1,1,1,"127.0.0.1","ADMINISTRADOR",1),
(2,10907085,"LP","Chambi","Bautista","Luis","1995-03-22",67333533,"San Felipe","2021-02-15 17:47:00","2021-05-25 21:07:52",1,"LUIS_10907085","13b6f194fc15b72a711b7bcea693bf5a3433a94138412450dd8e54e1ca16d1c1a10bc80d8942690137024e651190d56abcd94c239cba4dd506b78d057c6bfbf4","",2,2,2,"127.0.0.1","ODONTOLOGO",1),
(3,10907080,"LP","Flores","Campos","Jorge Luis","1999-02-16",7658956,"kiswaras","2021-02-19 18:01:47","2021-06-22 21:55:36",1,"JORGE_10907080","6ee7c7c5db1e16ae05d0fa94a743f7a6a573dcbcd2d7d1c698bf891584c77030be3fd5e7fa1180ad80509e5291e9fd9bd3c370b93b2f54f82eed2c899e8c8cbe","img/users/1624415689_9a34ae7efe6d4b0ead1f.png",3,3,3,"127.0.0.1","PACIENTE",1),
(4,25896312,"CH","Cortez","Charca","Hernan","1995-03-22",25896321,"Pinos ","2021-02-19 18:03:22","2021-06-22 19:38:19",1,"HERNAN_25896312","13b6f194fc15b72a711b7bcea693bf5a3433a94138412450dd8e54e1ca16d1c1a10bc80d8942690137024e651190d56abcd94c239cba4dd506b78d057c6bfbf4","",4,3,4,"127.0.0.1","PACIENTE",1),
(5,14785896,"LP","Montes","Carbajal","Pablo","1708-02-15",78596321,"Senkata","2021-02-19 18:07:43","2021-03-17 23:01:27",1,"PABLO_14785896","e9c1f76bcf22743e80a20529a38f89bfedae0e9bb386f67205ee5f558a577626cf63dbbc9d68830dbaf4fcbd2e5c39c65b318026f778ebc3020430a3dd72fdd2","",5,2,5,"127.0.0.1","ODONTOLOGO",1),
(6,20252365,"CH","Terrazas","Curvo","Franklim","2021-03-01",75896325,"palos blancos","2021-03-12 19:41:06","2021-06-09 00:52:52",1,"FRANKLIM_20252365","3f3c994433fc03012a5c1d6b0e09dc1063c58d2aeb05e43fdfdaa0ae67c2d10367e342e337b77f8872805b1b2c333e23642fa7460852a6c4912619d9fe96c334","",6,3,6,"127.0.0.1","PACIENTE",1);


SET foreign_key_checks = 1;
